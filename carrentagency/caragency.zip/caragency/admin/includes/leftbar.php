	<nav class="ts-sidebar">
		<ul class="ts-sidebar-menu">

			<li class="ts-label">Main</li>
			<li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
			<li><a href="post-avehical.php"><i class="fa fa-sitemap"></i> Post a Vehicle</a></li>
			<li><a href="manage-vehicles.php"><i class="fa fa-car"></i>Manage Vehicles</a></li>
			<li><a href="manage-bookings.php"><i class="fa fa-users"></i> Manage Booking</a></li>
			<li><a href="#"><i class="fa-solid fa-list"></i></i> Other </a></li>


		</ul>
	</nav>